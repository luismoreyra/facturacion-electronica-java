/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cursojavafacele;

import java.io.File;
import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

/**
 *
 * @author jose
 */
public class CPESunatUBL21 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GenerarXMLCPE();
    }
    
    public static int GenerarXMLCPE() {
        try {
            String xmlCPE="";
            xmlCPE="<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" +
"<Invoice xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:cac=\"urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2\" xmlns:cbc=\"urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2\" xmlns:ccts=\"urn:un:unece:uncefact:documentation:2\" xmlns:ds=\"http://www.w3.org/2000/09/xmldsig#\" xmlns:ext=\"urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2\" xmlns:qdt=\"urn:oasis:names:specification:ubl:schema:xsd:QualifiedDatatypes-2\" xmlns:udt=\"urn:un:unece:uncefact:data:specification:UnqualifiedDataTypesSchemaModule:2\" xmlns=\"urn:oasis:names:specification:ubl:schema:xsd:Invoice-2\">\n" +
"  <ext:UBLExtensions>\n" +
"    <ext:UBLExtension>\n" +
"      <ext:ExtensionContent>\n" +
"	  </ext:ExtensionContent>\n" +
"    </ext:UBLExtension>\n" +
"  </ext:UBLExtensions>\n" +
"  <cbc:UBLVersionID>2.1</cbc:UBLVersionID>\n" +
"  <cbc:CustomizationID schemeAgencyName=\"PE:SUNAT\">2.0</cbc:CustomizationID>\n" +
"  <cbc:ProfileID schemeName=\"Tipo de Operacion\" schemeAgencyName=\"PE:SUNAT\" schemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo51\">0101</cbc:ProfileID>\n" +
"  <cbc:ID>F001-0000003</cbc:ID>\n" +
"  <cbc:IssueDate>2018-07-26</cbc:IssueDate>\n" +
"  <cbc:IssueTime>00:00:00</cbc:IssueTime>\n" +
"  <cbc:DueDate>2018-07-26</cbc:DueDate>\n" +
"  <cbc:InvoiceTypeCode listAgencyName=\"PE:SUNAT\" listName=\"Tipo de Documento\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo01\" listID=\"0101\" name=\"Tipo de Operacion\" listSchemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo51\">01</cbc:InvoiceTypeCode>\n" +
"  <cbc:Note languageLocaleID=\"1000\">setenta y cuatro con 34/100</cbc:Note>\n" +
"  <cbc:DocumentCurrencyCode listID=\"ISO 4217 Alpha\" listName=\"Currency\" listAgencyName=\"United Nations Economic Commission for Europe\">PEN</cbc:DocumentCurrencyCode>\n" +
"  <cbc:LineCountNumeric>2</cbc:LineCountNumeric>\n" +
"  <cac:Signature>\n" +
"    <cbc:ID>F001-0000003</cbc:ID>\n" +
"    <cac:SignatoryParty>\n" +
"      <cac:PartyIdentification>\n" +
"        <cbc:ID>10447915125</cbc:ID>\n" +
"      </cac:PartyIdentification>\n" +
"      <cac:PartyName>\n" +
"        <cbc:Name>JOSE LUIS ZAMBRANO YACHA</cbc:Name>\n" +
"      </cac:PartyName>\n" +
"    </cac:SignatoryParty>\n" +
"    <cac:DigitalSignatureAttachment>\n" +
"      <cac:ExternalReference>\n" +
"        <cbc:URI>#F001-0000003</cbc:URI>\n" +
"      </cac:ExternalReference>\n" +
"    </cac:DigitalSignatureAttachment>\n" +
"  </cac:Signature>\n" +
"  <cac:AccountingSupplierParty>\n" +
"    <cac:Party>\n" +
"      <cac:PartyIdentification>\n" +
"        <cbc:ID schemeID=\"6\" schemeName=\"Documento de Identidad\" schemeAgencyName=\"PE:SUNAT\" schemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06\">10447915125</cbc:ID>\n" +
"      </cac:PartyIdentification>\n" +
"      <cac:PartyName>\n" +
"        <cbc:Name><![CDATA[JOSE LUIS ZAMBRANO YACHA]]></cbc:Name>\n" +
"      </cac:PartyName>\n" +
"      <cac:PartyTaxScheme>\n" +
"        <cbc:RegistrationName><![CDATA[JOSE LUIS ZAMBRANO YACHA]]></cbc:RegistrationName>\n" +
"        <cbc:CompanyID schemeID=\"6\" schemeName=\"SUNAT:Identificador de Documento de Identidad\" schemeAgencyName=\"PE:SUNAT\" schemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06\">10447915125</cbc:CompanyID>\n" +
"        <cac:TaxScheme>\n" +
"          <cbc:ID schemeID=\"6\" schemeName=\"SUNAT:Identificador de Documento de Identidad\" schemeAgencyName=\"PE:SUNAT\" schemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06\">10447915125</cbc:ID>\n" +
"        </cac:TaxScheme>\n" +
"      </cac:PartyTaxScheme>\n" +
"      <cac:PartyLegalEntity>\n" +
"        <cbc:RegistrationName><![CDATA[JOSE LUIS ZAMBRANO YACHA]]></cbc:RegistrationName>\n" +
"        <cac:RegistrationAddress>\n" +
"          <cbc:ID schemeName=\"Ubigeos\" schemeAgencyName=\"PE:INEI\" />\n" +
"          <cbc:AddressTypeCode listAgencyName=\"PE:SUNAT\" listName=\"Establecimientos anexos\">0000</cbc:AddressTypeCode>\n" +
"          <cbc:CityName><![CDATA[]]></cbc:CityName>\n" +
"          <cbc:CountrySubentity><![CDATA[]]></cbc:CountrySubentity>\n" +
"          <cbc:District><![CDATA[]]></cbc:District>\n" +
"          <cac:AddressLine>\n" +
"            <cbc:Line><![CDATA[]]></cbc:Line>\n" +
"          </cac:AddressLine>\n" +
"          <cac:Country>\n" +
"            <cbc:IdentificationCode listID=\"ISO 3166-1\" listAgencyName=\"United Nations Economic Commission for Europe\" listName=\"Country\">PE</cbc:IdentificationCode>\n" +
"          </cac:Country>\n" +
"        </cac:RegistrationAddress>\n" +
"      </cac:PartyLegalEntity>\n" +
"      <cac:Contact>\n" +
"        <cbc:Name><![CDATA[]]></cbc:Name>\n" +
"      </cac:Contact>\n" +
"    </cac:Party>\n" +
"  </cac:AccountingSupplierParty>\n" +
"  <cac:AccountingCustomerParty>\n" +
"    <cac:Party>\n" +
"      <cac:PartyIdentification>\n" +
"        <cbc:ID schemeID=\"6\" schemeName=\"Documento de Identidad\" schemeAgencyName=\"PE:SUNAT\" schemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06\">20424964990</cbc:ID>\n" +
"      </cac:PartyIdentification>\n" +
"      <cac:PartyName>\n" +
"        <cbc:Name><![CDATA[CARVIMSA]]></cbc:Name>\n" +
"      </cac:PartyName>\n" +
"      <cac:PartyTaxScheme>\n" +
"        <cbc:RegistrationName><![CDATA[CARVIMSA]]></cbc:RegistrationName>\n" +
"        <cbc:CompanyID schemeID=\"6\" schemeName=\"SUNAT:Identificador de Documento de Identidad\" schemeAgencyName=\"PE:SUNAT\" schemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06\">20424964990</cbc:CompanyID>\n" +
"        <cac:TaxScheme>\n" +
"          <cbc:ID schemeID=\"6\" schemeName=\"SUNAT:Identificador de Documento de Identidad\" schemeAgencyName=\"PE:SUNAT\" schemeURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo06\">20424964990</cbc:ID>\n" +
"        </cac:TaxScheme>\n" +
"      </cac:PartyTaxScheme>\n" +
"      <cac:PartyLegalEntity>\n" +
"        <cbc:RegistrationName><![CDATA[CARVIMSA]]></cbc:RegistrationName>\n" +
"        <cac:RegistrationAddress>\n" +
"          <cbc:ID schemeName=\"Ubigeos\" schemeAgencyName=\"PE:INEI\">\n" +
"          </cbc:ID>\n" +
"          <cbc:CityName><![CDATA[]]></cbc:CityName>\n" +
"          <cbc:CountrySubentity><![CDATA[]]></cbc:CountrySubentity>\n" +
"          <cbc:District><![CDATA[]]></cbc:District>\n" +
"          <cac:AddressLine>\n" +
"            <cbc:Line><![CDATA[DIRECCION]]></cbc:Line>\n" +
"          </cac:AddressLine>\n" +
"          <cac:Country>\n" +
"            <cbc:IdentificationCode listID=\"ISO 3166-1\" listAgencyName=\"United Nations Economic Commission for Europe\" listName=\"Country\">PE</cbc:IdentificationCode>\n" +
"          </cac:Country>\n" +
"        </cac:RegistrationAddress>\n" +
"      </cac:PartyLegalEntity>\n" +
"    </cac:Party>\n" +
"  </cac:AccountingCustomerParty>\n" +
"  <cac:TaxTotal>\n" +
"    <cbc:TaxAmount currencyID=\"PEN\">11.34</cbc:TaxAmount>\n" +
"    <cac:TaxSubtotal>\n" +
"      <cbc:TaxableAmount currencyID=\"PEN\">48</cbc:TaxableAmount>\n" +
"      <cbc:TaxAmount currencyID=\"PEN\">11.34</cbc:TaxAmount>\n" +
"      <cac:TaxCategory>\n" +
"        <cbc:ID schemeID=\"UN/ECE 5305\" schemeName=\"Tax Category Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">S</cbc:ID>\n" +
"        <cac:TaxScheme>\n" +
"          <cbc:ID schemeID=\"UN/ECE 5153\" schemeAgencyID=\"6\">1000</cbc:ID>\n" +
"          <cbc:Name>IGV</cbc:Name>\n" +
"          <cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>\n" +
"        </cac:TaxScheme>\n" +
"      </cac:TaxCategory>\n" +
"    </cac:TaxSubtotal>\n" +
"  </cac:TaxTotal>\n" +
"  <cac:LegalMonetaryTotal>\n" +
"    <cbc:PayableAmount currencyID=\"PEN\">74.34</cbc:PayableAmount>\n" +
"  </cac:LegalMonetaryTotal>\n" +
"  <cac:InvoiceLine>\n" +
"    <cbc:ID>1</cbc:ID>\n" +
"    <cbc:InvoicedQuantity unitCode=\"NIU\" unitCodeListID=\"UN/ECE rec 20\" unitCodeListAgencyName=\"United Nations Economic Commission for Europe\">5.00000</cbc:InvoicedQuantity>\n" +
"    <cbc:LineExtensionAmount currencyID=\"PEN\">15.00</cbc:LineExtensionAmount>\n" +
"    <cac:PricingReference>\n" +
"      <cac:AlternativeConditionPrice>\n" +
"        <cbc:PriceAmount currencyID=\"PEN\">3.00</cbc:PriceAmount>\n" +
"        <cbc:PriceTypeCode listName=\"Tipo de Precio\" listAgencyName=\"PE:SUNAT\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo16\">01</cbc:PriceTypeCode>\n" +
"      </cac:AlternativeConditionPrice>\n" +
"    </cac:PricingReference>\n" +
"    <cac:TaxTotal>\n" +
"      <cbc:TaxAmount currencyID=\"PEN\">3.00</cbc:TaxAmount>\n" +
"      <cac:TaxSubtotal>\n" +
"        <cbc:TaxableAmount currencyID=\"PEN\">15.00</cbc:TaxableAmount>\n" +
"        <cbc:TaxAmount currencyID=\"PEN\">3.00</cbc:TaxAmount>\n" +
"        <cac:TaxCategory>\n" +
"          <cbc:ID schemeID=\"UN/ECE 5305\" schemeName=\"Tax Category Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">S</cbc:ID>\n" +
"          <cbc:Percent>18</cbc:Percent>\n" +
"          <cbc:TaxExemptionReasonCode listAgencyName=\"PE:SUNAT\" listName=\"SUNAT:Codigo de Tipo de Afectación del IGV\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo07\">10</cbc:TaxExemptionReasonCode>\n" +
"          <cac:TaxScheme>\n" +
"            <cbc:ID schemeID=\"UN/ECE 5153\" schemeName=\"Tax Scheme Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">1000</cbc:ID>\n" +
"            <cbc:Name>IGV</cbc:Name>\n" +
"            <cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>\n" +
"          </cac:TaxScheme>\n" +
"        </cac:TaxCategory>\n" +
"      </cac:TaxSubtotal>\n" +
"    </cac:TaxTotal>\n" +
"    <cac:Item>\n" +
"      <cbc:Description><![CDATA[PRODUCTO]]></cbc:Description>\n" +
"      <cac:SellersItemIdentification>\n" +
"        <cbc:ID><![CDATA[0001]]></cbc:ID>\n" +
"      </cac:SellersItemIdentification>\n" +
"    </cac:Item>\n" +
"    <cac:Price>\n" +
"      <cbc:PriceAmount currencyID=\"PEN\">3.00</cbc:PriceAmount>\n" +
"    </cac:Price>\n" +
"  </cac:InvoiceLine>\n" +
"  <cac:InvoiceLine>\n" +
"    <cbc:ID>2</cbc:ID>\n" +
"    <cbc:InvoicedQuantity unitCode=\"NIU\" unitCodeListID=\"UN/ECE rec 20\" unitCodeListAgencyName=\"United Nations Economic Commission for Europe\">8.00000</cbc:InvoicedQuantity>\n" +
"    <cbc:LineExtensionAmount currencyID=\"PEN\">48.00</cbc:LineExtensionAmount>\n" +
"    <cac:PricingReference>\n" +
"      <cac:AlternativeConditionPrice>\n" +
"        <cbc:PriceAmount currencyID=\"PEN\">6.00</cbc:PriceAmount>\n" +
"        <cbc:PriceTypeCode listName=\"Tipo de Precio\" listAgencyName=\"PE:SUNAT\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo16\">01</cbc:PriceTypeCode>\n" +
"      </cac:AlternativeConditionPrice>\n" +
"    </cac:PricingReference>\n" +
"    <cac:TaxTotal>\n" +
"      <cbc:TaxAmount currencyID=\"PEN\">9.00</cbc:TaxAmount>\n" +
"      <cac:TaxSubtotal>\n" +
"        <cbc:TaxableAmount currencyID=\"PEN\">48.00</cbc:TaxableAmount>\n" +
"        <cbc:TaxAmount currencyID=\"PEN\">9.00</cbc:TaxAmount>\n" +
"        <cac:TaxCategory>\n" +
"          <cbc:ID schemeID=\"UN/ECE 5305\" schemeName=\"Tax Category Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">S</cbc:ID>\n" +
"          <cbc:Percent>18</cbc:Percent>\n" +
"          <cbc:TaxExemptionReasonCode listAgencyName=\"PE:SUNAT\" listName=\"SUNAT:Codigo de Tipo de Afectación del IGV\" listURI=\"urn:pe:gob:sunat:cpe:see:gem:catalogos:catalogo07\">10</cbc:TaxExemptionReasonCode>\n" +
"          <cac:TaxScheme>\n" +
"            <cbc:ID schemeID=\"UN/ECE 5153\" schemeName=\"Tax Scheme Identifier\" schemeAgencyName=\"United Nations Economic Commission for Europe\">1000</cbc:ID>\n" +
"            <cbc:Name>IGV</cbc:Name>\n" +
"            <cbc:TaxTypeCode>VAT</cbc:TaxTypeCode>\n" +
"          </cac:TaxScheme>\n" +
"        </cac:TaxCategory>\n" +
"      </cac:TaxSubtotal>\n" +
"    </cac:TaxTotal>\n" +
"    <cac:Item>\n" +
"      <cbc:Description><![CDATA[PRUEBA ARTICULO 2]]></cbc:Description>\n" +
"      <cac:SellersItemIdentification>\n" +
"        <cbc:ID><![CDATA[0002]]></cbc:ID>\n" +
"      </cac:SellersItemIdentification>\n" +
"    </cac:Item>\n" +
"    <cac:Price>\n" +
"      <cbc:PriceAmount currencyID=\"PEN\">6.00</cbc:PriceAmount>\n" +
"    </cac:Price>\n" +
"  </cac:InvoiceLine>\n" +
"</Invoice>";
            
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(xmlCPE)));
            // Use a Transformer for output
            TransformerFactory tFactory = TransformerFactory.newInstance();
            Transformer transformer = tFactory.newTransformer();

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File("D:\\CPE\\BETA\\10447915125-01-F001-0000003.XML"));
            transformer.transform(source, result);

            System.out.println("\nXML DOM Created Successfully..");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 1;
    }
    
}
